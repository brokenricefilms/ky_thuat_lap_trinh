#include "header.h"

int main() {
  DaySo a;
  nhapDaySo(a);
  xuatDaySo(a);
  cout << "\nTổng phần tử của dãy số là: " << tinhTongPhanTu(a) << endl;
  return 0;
}
